<?php
/**
 * Avelon Network.

 *
 * @category   Avelon
 * @package    Avelon_AvelonNetwork
 * @author     pixable
 * @copyright  Copyright (c) Avelon Network Ltd ( https://avelonetwork.com/ )
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Avelon_AvelonNetwork',
    __DIR__
);
