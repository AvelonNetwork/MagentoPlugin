<?php
/**
 * Avelon Network.

 *
 * @category   Avelon
 * @package    AndrewAvelonetwork_AvelonNetworkAffiliateMarketing
 * @author     pixable
 * @copyright  Copyright (c) Avelon Network Ltd ( https://avelonetwork.com/ )
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'AndrewAvelonetwork_AvelonNetworkAffiliateMarketing',
    __DIR__
);
